defmodule Item do
    defstruct name: "", sell_in: 0, quality: 0 
end