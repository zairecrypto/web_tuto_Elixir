defmodule GildedRoseTest do
  use ExUnit.Case
  
end